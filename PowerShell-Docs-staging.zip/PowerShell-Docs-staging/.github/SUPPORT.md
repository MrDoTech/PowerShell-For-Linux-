---
name: Support Question ❓
about: Try asking in the PowerShell Slack channel first. For official support, refer to the PowerShell Support Lifecycle at https://aka.ms/pslifecycle
title: "Support Question"
labels: issue-question
assignees: ''

---

# Support Question

## Official support

[PowerShell Support Lifecycle](https://aka.ms/pslifecycle)

## Community Resources

See the [Community support](https://docs.microsoft.com/powershell/scripting/community/community-support)
for more links to community-based support forums.
