---
description:  Provides a brief introduction to the PowerShell Desired State Configuration (DSC) Log Resource. LONG DESCRIPTION 
keywords: powershell,cmdlet
Locale: en-US
ms.date: 06/09/2017
online version: https://docs.microsoft.com/powershell/module/microsoft.powershell.core/about/about_dsclogresource?view=powershell-5.1&WT.mc_id=ps-gethelp
schema: 2.0.0
title: about_DSCLogResource
---

# about_DSCLogResource

## SHORT DESCRIPTION

Provides a brief introduction to the PowerShell Desired State Configuration
(DSC) Log Resource. LONG DESCRIPTION

## LONG DESCRIPTION

## HOW TO USE THE DSC LOG RESOURCE
