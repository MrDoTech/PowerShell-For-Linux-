---
Download Help Link: https://go.microsoft.com/fwlink/?LinkId=509916
Help Version: 5.2.0.0
keywords: powershell,cmdlet
Locale: en-US
Module Guid: fa1606d1-94cb-4264-bfb6-def714420084
Module Name: Microsoft.PowerShell.ODataUtils
ms.date: 06/09/2017
schema: 2.0.0
title: Microsoft.PowerShell.ODataUtils
---
# Microsoft.PowerShell.ODataUtils Module

## Description

This section contains the help topics for the Microsoft.PowerShell.ODataUtils module. The Microsoft.PowerShell.ODataUtils module is installed with Windows PowerShell 5.1.

## Microsoft.PowerShell.ODataUtils Cmdlets

### [Export-ODataEndpointProxy](Export-ODataEndpointProxy.md)
Generates a module that contains cmdlets to manage an OData endpoint.
